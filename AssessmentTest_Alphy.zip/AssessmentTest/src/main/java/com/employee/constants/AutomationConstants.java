package com.employee.constants;

public class AutomationConstants {
	
	public static String expUsername="practice.swtesting@gmail.com";
	public static String expLPassword="123";
	public static String expTitle=":: ICT ACADEMY OF KERALA ::";
	public static String expName="Alphy";
	public static String expId="9874";
	public static String expEPassword="123";
	public static String expCPassword="123";
	public static String expEmail="alphy@gmail.com";
	public static String expPhone="9632587410";
	public static String expDesignation="HR";
	public static String expEType="Permanant";
	public static String expReporting="Demo";
	public static String expMember="HR";
	public static String expAddress="Ernakulam";

}
